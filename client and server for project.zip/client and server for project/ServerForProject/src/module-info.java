module ServerForProject {
    requires java.sql; // For database operations
    requires HealthDataLogger; // Access the database through HealthDataLogger
}

