module HealthDataLogger {
    requires javafx.controls; // For JavaFX applications
    requires javafx.fxml; // For FXML
    requires java.sql; // For database operations

    // Export only necessary packages
    exports startingPoint;
    exports technicianHome;
    exports patientAccountManagement;
    exports healthDataRecords;

    // Export `database` only to `ServerForProject`
    exports database to ServerForProject;

    // Open packages for reflection (FXML)
    opens technicianHome to javafx.fxml;
    opens patientAccountManagement to javafx.fxml;
    opens healthDataRecords to javafx.fxml;
}




